# Tank vs Zombie — Story Intro Voice-Over (SYNTHETIC DRAFT)

This package contains 66 locally synthesized MP3 **preview tracks**: 11 lines in English (en), Hindi (hi), Marathi (mr), Telugu (te), Odia (or), and Gujarati (gu).

**Important: this is NOT a finished voice-actor recording.** The local offline speech engine has synthetic robotic prosody and cannot match the requested warm, confident early-20s female commander. It lacks native Marathi and Odia support. Marathi tracks use a Hindi synthesis fallback; Odia text is approximated by transliteration into Bengali and read using a Bengali voice. Telugu and Gujarati use experimental eSpeak voices. Replace all tracks with reviewed native-language recordings before publishing.

## File layout
- `assets/vo/<lang>/story_01.mp3` ... `story_09.mp3`, `end_01.mp3`, `end_02.mp3`
- `i18n/story_captions.json`: text taken exactly from the supplied script, 6 languages.
- `story_vo_manifest.json`: all lines, delivery directions, file paths and durations.
- `translation_and_vo_review.csv`: full per-line review checklist.

## Audio engineering
Rendered as mono 44.1 kHz MP3 at 128 kb/s using two-pass ffmpeg loudnorm targeting −16 LUFS integrated and peak ceiling −1 dBTP. Leading/trailing silence is approximately 80 ms before MP3 codec delay/priming. No music, effects, or additional speech.

## Game integration
Copy the `assets/vo` folder into your game project. Merge the language-specific `i18n/story_captions.json` keys into your existing `i18n/strings.json` rather than overwriting it. Use the same key for the caption and the VO file. Replace the MP3 drafts with final actor/quality TTS recordings at the same paths after native-language QA.

## Voice director brief (for final production)
One warm, brave, reassuring, playful female commander; early twenties; 130–140 WPM where natural. Not a drill sergeant. Distinguish wonder (01), playful alarm (02), determination (03), urgency (04), invitation (05), focus (06), curiosity (07), clear teaching (08), excitement (09), relief (end_01), and celebration (end_02). Long translations may naturally take over five seconds; prioritize intelligibility.
