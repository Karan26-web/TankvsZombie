#!/usr/bin/env python3
"""Create locally synthesized VO *drafts* for Tank vs Zombie: Angle Academy.

Uses eSpeak (no network) and ffmpeg. These are NOT native-speaker-reviewed
recordings and are NOT intended for production use. Marathi falls back to the
Hindi voice; Odia is script-transliterated to Bengali with a Bengali voice.
They should be replaced with native-language studio/neurally voiced recordings.
"""
from __future__ import annotations
import csv
import json
import re
import shutil
import subprocess
import tempfile
import unicodedata
import wave
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from statistics import mean

import numpy as np

SOURCE=Path(__file__).resolve().parent/'source_STORY_VO.md'
ROOT=Path(__file__).resolve().parent
ASSET=ROOT/'assets'/'vo'
LANGS=['en','hi','mr','te','or','gu']
NAMES={'en':'English','hi':'Hindi','mr':'Marathi','te':'Telugu','or':'Odia','gu':'Gujarati'}
VOICES={'en':'en-us+f4','hi':'hi+f4','mr':'hi+f4','te':'te+f4','or':'bn+f4','gu':'gu+f4'}
NOTES={'en':'English local eSpeak preview voice, approximate young-female timbre',
       'hi':'Hindi local eSpeak preview voice; check all phonemes and prosody',
       'mr':'Marathi approximate: synthesised using the Hindi phonemizer; not a native Marathi voice',
       'te':'Telugu eSpeak test voice; pronunciation and prosody require native review',
       'or':'Odia approximate: script transliterated into Bengali, then Bengali voice; not a native Odia recording',
       'gu':'Gujarati eSpeak test voice; pronunciation and prosody require native review'}
DELIVERY={
  'story_01':('wonder / welcoming','130'),
  'story_02':('fun alarm, half-laugh','142'),
  'story_03':('determined / planning','136'),
  'story_04':('urgent rising energy','147'),
  'story_05':('cheerful / ready','143'),
  'story_06':('quiet / focused','130'),
  'story_07':('curious invitation to answer','136'),
  'story_08':('calm / teaching','132'),
  'story_09':('bright invitation','143'),
  'end_01':('relieved / upbeat','139'),
  'end_02':('triumphant / celebrating','145'),
}
PITCH={'story_01':67,'story_02':75,'story_03':63,'story_04':76,'story_05':74,
       'story_06':59,'story_07':69,'story_08':62,'story_09':77,
       'end_01':70,'end_02':80}


def parse_lines(src:Path):
    raw=src.read_text(encoding='utf-8')
    parts=re.split(r'^###\s+(story_\d\d|end_\d\d)\s+—',raw,flags=re.M)
    lines={}
    for i in range(1,len(parts),2):
        key=parts[i]
        entries=re.findall(r'^\|\s*(en|hi|mr|te|or|gu)\s*\|\s*(.+?)\s*\|\s*$',parts[i+1],flags=re.M)
        if len(entries)!=6: raise RuntimeError(f'{key}: expected 6 translations, got {len(entries)}')
        lines[key]=dict(entries)
    expected=[f'story_{i:02}' for i in range(1,10)]+['end_01','end_02']
    if list(lines)!=expected: raise RuntimeError(f'wrong IDs: {list(lines)}')
    for key, vals in lines.items():
        if set(vals)!=set(LANGS):raise RuntimeError(f'missing language for {key}')
    return lines


def to_bengali_spelling(odia:str)->str:
    """Approximate *orthographic* mapping, not true Odia phonological synthesis."""
    repl={
       '\u0b33':'\u09b2', # Odia retroflex la -> Bengali la approximation
       '\u0b71':'\u09f1', # Odia wa -> Bengali wa
       '\u0b70':'\u09f0',
       '\u0b5f':'\u09df',
    }
    out=[]
    for ch in odia:
        if ch in repl:out.append(repl[ch]);continue
        cp=ord(ch)
        if 0x0B00 <= cp <= 0x0B7F:
            candidate=chr(cp-0x180)
            if unicodedata.category(candidate)=='Cn':
                # Fallback: omit unsupported mark rather than output unrelated glyph.
                continue
            out.append(candidate)
        else:out.append(ch)
    return ''.join(out)


def run(*args, input=None):
    p=subprocess.run(args,input=input,capture_output=True,text=True,encoding="utf-8",errors="replace")
    if p.returncode:
        raise RuntimeError(f'command failed: {args[:4]} ... {p.stderr[-1000:]}')
    return p


def trim_and_pad_espeak_wav(source:Path, dest:Path):
    with wave.open(str(source),'rb') as f:
        params=f.getparams()
        if params.nchannels!=1 or params.sampwidth!=2:
            raise RuntimeError('Unexpected espeak format')
        sr=params.framerate
        samples=np.frombuffer(f.readframes(params.nframes),dtype='<i2')
    absx=np.abs(samples.astype(np.float64))
    # Smooth audio amplitude (10ms) and find the outermost meaningful speech.
    width=max(1,int(0.01*sr))
    sq=np.convolve(absx, np.ones(width)/width, mode='same')
    nonzero=np.where(sq>=110)[0]  # ~-49.5 dBFS
    if len(nonzero)<100:raise RuntimeError(f'No speech detected in {source}')
    cropped=samples[max(0,int(nonzero[0])-width):min(len(samples),int(nonzero[-1])+width+1)]
    silence=np.zeros(round(sr*.080),dtype='<i2')
    output=np.concatenate((silence,cropped,silence))
    with wave.open(str(dest),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr)
        f.writeframes(output.tobytes())
    return len(output)/sr


def loudnorm_to_mp3(source:Path, dest:Path):
    # First pass measures programme loudness. Second pass targets -16 LUFS,
    # -1 dBTP and preserves the original pre/post padded silence.
    spec='loudnorm=I=-16:TP=-1:LRA=7'
    r=run('ffmpeg','-hide_banner','-nostdin','-i',str(source),'-filter:a',spec+':print_format=json','-f','null','-')
    measured=re.search(r'\{\s*"input_i".*?\}',r.stderr,re.S)
    if not measured:raise RuntimeError('Could not read loudnorm measurement '+r.stderr[-600:])
    data=json.loads(measured.group(0))
    filter2=(f'{spec}:measured_I={data["input_i"]}:measured_TP={data["input_tp"]}:'
             f'measured_LRA={data["input_lra"]}:measured_thresh={data["input_thresh"]}:'
             f'offset={data["target_offset"]}:linear=true:print_format=summary')
    r2=run('ffmpeg','-hide_banner','-nostdin','-y','-i',str(source),'-filter:a',filter2,
           '-ac','1','-ar','44100','-c:a','libmp3lame','-b:a','128k','-write_xing','1',str(dest))
    return data


def render(item):
    key,lang,text=item
    voice=VOICES[lang]
    use_text=to_bengali_spelling(text) if lang=='or' else text
    speed=DELIVERY[key][1]
    pitch=PITCH[key]
    dest=ASSET/lang/(key+'.mp3')
    dest.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='tz_vo_') as td:
        td=Path(td)
        wav=td/'espeak.wav'
        pad=td/'padded.wav'
        run('espeak','-v',voice,'-s',speed,'-p',str(pitch),'-a','160','-w',str(wav),use_text)
        length=trim_and_pad_espeak_wav(wav,pad)
        measured=loudnorm_to_mp3(pad,dest)
    ff=json.loads(run('ffprobe','-v','error','-show_entries','stream=sample_rate,channels,bit_rate,duration','-of','json',str(dest)).stdout)
    track=ff['streams'][0]
    if track['sample_rate']!='44100' or track['channels']!=1:raise RuntimeError(f'Bad encoding: {dest} {track}')
    return { 'id':key, 'lang':lang, 'file':f'assets/vo/{lang}/{key}.mp3',
             'caption':text, 'delivery':DELIVERY[key][0],
             'duration_sec':round(float(track.get('duration',length)),2),
             'bit_rate':int(track['bit_rate']), 'preview_voice':voice,
             'pronunciation_status':'needs native review',
             'needs_long_line_review': float(track.get('duration',length))>5.0,
           }


def main():
    lines=parse_lines(SOURCE)
    ASSET.mkdir(parents=True,exist_ok=True)
    tasks=[(key,lang,content[lang]) for lang in LANGS for key,content in lines.items()]
    all_results=[]
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures={pool.submit(render,x):x for x in tasks}
        for i,fut in enumerate(as_completed(futures),1):
            try:all_results.append(fut.result())
            except Exception as e: raise RuntimeError(f'Failed on {futures[fut]}') from e
            if i%11==0:print('Rendered',i,'of 66',flush=True)
    resultmap={(r['id'],r['lang']):r for r in all_results}
    manifest={
      'project':'Tank vs Zombie — Angle Academy',
      'release_status':'SYNTHETIC PREVIEW ONLY — NOT FOR PRODUCTION',
      'voice_intent':'Young woman commander, warm, brave, encouraging, playful; final voice should be humanlike and consistent across languages.',
      'local_preview_engine':'eSpeak with ffmpeg loudness normalization',
      'note':'Audio is intelligibility/reference only. Marathi and Odia use non-native language fallbacks. All languages need pronunciation, translation and performance review before release.',
      'target_audio':{'format':'mp3','channels':1,'sample_rate_hz':44100,'bitrate_kbps':128,'integrated_lufs':-16,'max_true_peak_dbtp':-1,'silence_leading_trailing_ms':80},
      'languages':{lang:{'name':NAMES[lang],'preview_voice':VOICES[lang],'qa_note':NOTES[lang]} for lang in LANGS},
      'lines':[
        {'id':key, 'caption':content, 'delivery':DELIVERY[key][0],
         'paths':{lang:f'assets/vo/{lang}/{key}.mp3' for lang in LANGS},
         'duration_s':{lang:resultmap[(key,lang)]['duration_sec'] for lang in LANGS}}
        for key,content in lines.items()
      ]
    }
    (ROOT/'story_vo_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # Strings to merge into existing i18n/strings.json; no existing file is changed.
    (ROOT/'i18n').mkdir(parents=True,exist_ok=True)
    (ROOT/'i18n'/'story_captions.json').write_text(json.dumps({lang:{key:content[lang] for key,content in lines.items()} for lang in LANGS},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (ROOT/'translation_and_vo_review.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f)
        writer.writerow(['id','lang','language','exact_caption','delivery','mp3_path','preview_voice','duration_sec','over_5_sec','native_translation_review','native_pronunciation_review','performance_review'])
        for lang in LANGS:
            for key,content in lines.items():
                r=resultmap[(key,lang)]
                writer.writerow([key,lang,NAMES[lang],content[lang],DELIVERY[key][0],r['file'],VOICES[lang],r['duration_sec'],r['needs_long_line_review'],'PENDING','PENDING','PENDING'])
    readme='''# Tank vs Zombie — Story Intro Voice-Over (SYNTHETIC DRAFT)

This package contains 66 locally synthesized MP3 **preview tracks**: 11 lines in English (en), Hindi (hi), Marathi (mr), Telugu (te), Odia (or), and Gujarati (gu).

**Important: this is NOT a finished voice-actor recording.** The local offline speech engine has synthetic robotic prosody and cannot match the requested warm, confident early-20s female commander. It lacks native Marathi and Odia support. Marathi tracks use a Hindi synthesis fallback; Odia text is approximated by transliteration into Bengali and read using a Bengali voice. Telugu and Gujarati use experimental eSpeak voices. Replace all tracks with reviewed native-language recordings before publishing.

## File layout
- `assets/vo/<lang>/story_01.mp3` ... `story_09.mp3`, `end_01.mp3`, `end_02.mp3`
- `i18n/story_captions.json`: text taken exactly from the supplied script, 6 languages.
- `story_vo_manifest.json`: all lines, delivery directions, file paths and durations.
- `translation_and_vo_review.csv`: full per-line review checklist.

## Audio engineering
Rendered as mono 44.1 kHz MP3 at 128 kb/s using two-pass ffmpeg loudnorm targeting −16 LUFS integrated and peak ceiling −1 dBTP. Leading/trailing silence is approximately 80 ms before MP3 codec delay/priming. No music, effects, or additional speech.

## Game integration
Copy the `assets/vo` folder into your game project. Merge the language-specific `i18n/story_captions.json` keys into your existing `i18n/strings.json` rather than overwriting it. Use the same key for the caption and the VO file. Replace the MP3 drafts with final actor/quality TTS recordings at the same paths after native-language QA.

## Voice director brief (for final production)
One warm, brave, reassuring, playful female commander; early twenties; 130–140 WPM where natural. Not a drill sergeant. Distinguish wonder (01), playful alarm (02), determination (03), urgency (04), invitation (05), focus (06), curiosity (07), clear teaching (08), excitement (09), relief (end_01), and celebration (end_02). Long translations may naturally take over five seconds; prioritize intelligibility.
'''
    (ROOT/'README.md').write_text(readme,encoding='utf-8')
    print('Wrote',len(all_results),'MP3 files.', 'Mean duration:',round(mean(r['duration_sec'] for r in all_results),2),'s')
    print('>5s:',[(r['lang'],r['id'],r['duration_sec']) for r in all_results if r['needs_long_line_review']])
    return all_results

if __name__=='__main__':main()
